<li class="nav-item">
    <a class="nav-link" href="">
        <i class="fas fa-comments text-primary"></i>
        <span class="nav-link-text">Czat</span>
    </a>
</li>